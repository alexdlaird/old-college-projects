package numeric;

/**
 * An exception class which was added so the user could not enter
 * a negative number as his or her input.
 *
 * @author Alex Laird
 * @version 1.0
 * File: NegativeNumberException.java
 * Created: Sep 2008
 */
public class NegativeNumberException extends RuntimeException
{
    public NegativeNumberException()
    {
        // unused constructor
    }

    public NegativeNumberException(String msg)
    {
        // passes the error message to Exception
        super(msg);
    }
}
