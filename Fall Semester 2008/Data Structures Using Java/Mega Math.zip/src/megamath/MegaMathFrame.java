package megamath;

import numeric.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;

/**
 * MegaMath is a powerful GUI based application that allows the
 * user to calculate either the Greatest Common Divisor of two numbers of the
 * Factorial of one number.
 *
 * @author Alex Laird
 * @version 1.0
 * File: MegaMathFrame.java
 * Created: Sep 2008
 */
public class MegaMathFrame extends JFrame
{
    int gcdAnswer;
    double factAnswer;

    JPanel contentPane;
    JMenuBar jMenuBar = new JMenuBar();
    JMenu jMenuFile = new JMenu();
    JMenuItem jMenuFileExit = new JMenuItem();
    JMenu jMenuHelp = new JMenu();
    JMenuItem jMenuHelpAbout = new JMenuItem();
    JMenu jMenuCompute = new JMenu();
    JMenuItem jMenuComputeFactorial = new JMenuItem();
    JMenuItem jMenuComputeGreatestCommonDivisor = new JMenuItem();
    GridLayout gridLayoutMegaMathFrame = new GridLayout();
    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    JTextField jTextField2 = new JTextField();
    JTextField jTextField1 = new JTextField();
    JRadioButton jRadioButtonFactorial = new JRadioButton();
    JRadioButton jRadioButtonGCD = new JRadioButton();
    JButton jButtonCompute = new JButton();
    ButtonGroup buttonGroupCompute = new ButtonGroup();

    public MegaMathFrame()
    {
        try
        {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception
     */
    private void jbInit() throws Exception
    {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(gridLayoutMegaMathFrame);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setResizable(false);
        setSize(new Dimension(438, 144));
        setTitle("MegaMath");
        jMenuFile.setText("File");
        jMenuFileExit.setText("Exit");
        jMenuFileExit.addActionListener(new MegaMathFrame_jMenuFileExit_ActionAdapter(this));
        jMenuHelp.setText("Help");
        jMenuHelpAbout.setText("About");
        jMenuHelpAbout.addActionListener(new MegaMathFrame_jMenuHelpAbout_ActionAdapter(this));
        jMenuCompute.setText("Compute");
        jMenuComputeFactorial.setText("Factorial");
        jMenuComputeFactorial.addActionListener(new MegaMathFrame_jMenuComputeFactorial_actionAdapter(this));
        jMenuComputeGreatestCommonDivisor.setText("Greatest Common Divisor");
        jMenuComputeGreatestCommonDivisor.addActionListener(new MegaMathFrame_jMenuComputeGreatestCommonDivisor_actionAdapter(this));
        jLabel1.setText("First Number:");
        jTextField1.setText("");
        jRadioButtonFactorial.setSelected(true);
        jRadioButtonFactorial.setText("Compute Factorial");
        jRadioButtonFactorial.addActionListener(new MegaMathFrame_jRadioButtonFactorial_actionAdapter(this));
        jRadioButtonGCD.setText("Compute Greatest Common Divisor");
        jRadioButtonGCD.addActionListener(new MegaMathFrame_jRadioButtonGCD_actionAdapter(this));
        gridLayoutMegaMathFrame.setRows(4);
        jButtonCompute.setToolTipText("");
        jButtonCompute.setText("Compute");
        jButtonCompute.addActionListener(new MegaMathFrame_jButtonCompute_actionAdapter(this));
        jMenuBar.add(jMenuFile);
        jMenuFile.add(jMenuFileExit);
        jMenuBar.add(jMenuCompute);
        jMenuBar.add(jMenuHelp);
        jMenuHelp.add(jMenuHelpAbout);
        jMenuCompute.add(jMenuComputeFactorial);
        jMenuCompute.add(jMenuComputeGreatestCommonDivisor);
        contentPane.add(jRadioButtonFactorial);
        contentPane.add(jRadioButtonGCD);
        contentPane.add(jLabel1);
        contentPane.add(jTextField1);
        contentPane.add(jLabel2);
        contentPane.add(jTextField2);
        contentPane.add(jButtonCompute);
        setJMenuBar(jMenuBar);
        buttonGroupCompute.add(jRadioButtonFactorial);
        buttonGroupCompute.add(jRadioButtonGCD);

        // initialize second number inputs as false for Factorial since they aren't needed
        jLabel2.setVisible(false);
        jLabel2.setText("Second Number:");
        jTextField2.setVisible(false);
        jTextField2.setText("");
    }

    /**
     * File | Exit action performed.
     *
     * @param actionEvent ActionEvent
     */
    void jMenuFileExit_actionPerformed(ActionEvent actionEvent)
    {
        System.exit(0);
    }

    /**
     * Help | About action performed.
     *
     * @param actionEvent ActionEvent
     */
    void jMenuHelpAbout_actionPerformed(ActionEvent actionEvent)
    {
        MegaMathFrame_AboutBox dlg = new MegaMathFrame_AboutBox(this);
        Dimension dlgSize = dlg.getPreferredSize();
        Dimension frmSize = getSize();
        Point loc = getLocation();
        dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x,
                        (frmSize.height - dlgSize.height) / 2 + loc.y);
        dlg.setModal(true);
        dlg.pack();
        dlg.show();
    }
	
    public void jRadioButtonGCD_actionPerformed(ActionEvent e)
    {
        jLabel2.setVisible(true);
        jTextField2.setVisible(true);

        jTextField1.requestFocus();
    }
	
    public void jRadioButtonFactorial_actionPerformed(ActionEvent e)
    {
        jLabel2.setVisible(false);
        jTextField2.setVisible(false);

        jTextField1.setEnabled(true);
        jTextField1.requestFocus();
    }
	
    public void jButtonCompute_actionPerformed(ActionEvent e)
    {
        if(jRadioButtonFactorial.isSelected())
        {
            try
            {
                // throw an exception if the user enters no input
                if(jTextField1.getText().equals(""))
                {
                    throw new NullPointerException("No input entered.");
                }

                // call the calculation method in the numeric package
                factAnswer = numeric.Factorial.calcFactorial(Integer.parseInt(jTextField1.getText()));

                // construct the answer dialog box with Factorial information
                AnswerDialog ansDlg = new AnswerDialog(this, "Factorial", false,
													   jTextField1.getText(), factAnswer);
                Dimension ansDlgSize = ansDlg.getPreferredSize();
                Dimension ansFrmSize = getSize();
                Point loc = getLocation();
                ansDlg.setLocation((ansFrmSize.width - ansDlgSize.width) / 2 + loc.x,
                                   (ansFrmSize.height - ansDlgSize.height) / 2 + loc.y);
                ansDlg.setModal(true);
                ansDlg.pack();
                ansDlg.show();
            }
            catch(NumberFormatException c)
            {
                JOptionPane.showMessageDialog(this, "You must enter a number as your input.",
											  "Improper Input", JOptionPane.ERROR_MESSAGE);

                jTextField1.requestFocus();
            }
            catch(NullPointerException c)
            {
                JOptionPane.showMessageDialog(this, "The text field was left empty.",
											  "Improper Input", JOptionPane.ERROR_MESSAGE);

                jTextField1.requestFocus();
            }
            catch(NegativeNumberException c)
            {
                JOptionPane.showMessageDialog(this, "The number you enter must be positive.",
											  "Improper Input", JOptionPane.ERROR_MESSAGE);

                jTextField1.requestFocus();
            }
        }
        else
        {
            try
            {
                // throw an exception if the user enters no input
                if(jTextField1.getText().equals("") || jTextField2.getText().equals(""))
                {
                    throw new NullPointerException("No input entered.");
                }

                // call the calculation method in the numeric package
                gcdAnswer = numeric.GCD.gcd(Integer.parseInt(jTextField1.getText()),
											Integer.parseInt(jTextField2.getText()));

                // construct the answer dialog box with GCD information
                AnswerDialog ansDlg = new AnswerDialog(this, "Greatest Common Divisor", false,
													   jTextField1.getText() + " and " +
													   jTextField2.getText(), gcdAnswer);
                Dimension ansDlgSize = ansDlg.getPreferredSize();
                Dimension ansFrmSize = getSize();
                Point loc = getLocation();
                ansDlg.setLocation((ansFrmSize.width - ansDlgSize.width) / 2 + loc.x,
                                   (ansFrmSize.height - ansDlgSize.height) / 2 + loc.y);
                ansDlg.setModal(true);
                ansDlg.pack();
                ansDlg.show();
            }
            catch(NumberFormatException c)
            {
                JOptionPane.showMessageDialog(this, "You must enter two numbers as your inputs.",
											  "Improper Input", JOptionPane.ERROR_MESSAGE);

                jTextField1.requestFocus();
            }
            catch(NullPointerException c)
            {
                JOptionPane.showMessageDialog(this, "One or both of your input fields was left empty.",
											  "Improper Input", JOptionPane.ERROR_MESSAGE);

                jTextField1.requestFocus();
            }
            catch(NegativeNumberException c)
            {
                JOptionPane.showMessageDialog(this, "The numbers you enter must be positive.",
											  "Improper Input", JOptionPane.ERROR_MESSAGE);

                jTextField1.requestFocus();
            }
        }
    }

    public void jMenuComputeFactorial_actionPerformed(ActionEvent e)
    {
        jLabel2.setVisible(false);
        jTextField2.setVisible(false);
        jTextField1.setEnabled(true);
        jTextField1.requestFocus();
        jRadioButtonFactorial.setSelected(true);
    }

    public void jMenuComputeGreatestCommonDivisor_actionPerformed(ActionEvent e)
    {
        jLabel2.setVisible(true);
        jTextField2.setVisible(true);
        jTextField1.requestFocus();
        jRadioButtonGCD.setSelected(true);
    }
}

class MegaMathFrame_jMenuComputeGreatestCommonDivisor_actionAdapter implements ActionListener
{
    private MegaMathFrame adaptee;

    MegaMathFrame_jMenuComputeGreatestCommonDivisor_actionAdapter(MegaMathFrame adaptee)
    {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e)
    {
        adaptee.jMenuComputeGreatestCommonDivisor_actionPerformed(e);
    }
}

class MegaMathFrame_jButtonCompute_actionAdapter implements ActionListener
{
    private MegaMathFrame adaptee;

    MegaMathFrame_jButtonCompute_actionAdapter(MegaMathFrame adaptee)
    {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e)
    {
        adaptee.jButtonCompute_actionPerformed(e);
    }
}

class MegaMathFrame_jMenuComputeFactorial_actionAdapter implements ActionListener
{
    private MegaMathFrame adaptee;

    MegaMathFrame_jMenuComputeFactorial_actionAdapter(MegaMathFrame adaptee)
    {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e)
    {
        adaptee.jMenuComputeFactorial_actionPerformed(e);
    }
}

class MegaMathFrame_jRadioButtonGCD_actionAdapter implements ActionListener
{
    private MegaMathFrame adaptee;

    MegaMathFrame_jRadioButtonGCD_actionAdapter(MegaMathFrame adaptee)
    {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e)
    {
        adaptee.jRadioButtonGCD_actionPerformed(e);
    }
}

class MegaMathFrame_jRadioButtonFactorial_actionAdapter implements ActionListener
{
    private MegaMathFrame adaptee;

    MegaMathFrame_jRadioButtonFactorial_actionAdapter(MegaMathFrame adaptee)
    {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e)
    {
        adaptee.jRadioButtonFactorial_actionPerformed(e);
    }
}

class MegaMathFrame_jMenuFileExit_ActionAdapter implements ActionListener
{
    MegaMathFrame adaptee;

    MegaMathFrame_jMenuFileExit_ActionAdapter(MegaMathFrame adaptee)
    {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent)
    {
        adaptee.jMenuFileExit_actionPerformed(actionEvent);
    }
}

class MegaMathFrame_jMenuHelpAbout_ActionAdapter implements ActionListener
{
    MegaMathFrame adaptee;

    MegaMathFrame_jMenuHelpAbout_ActionAdapter(MegaMathFrame adaptee)
    {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent)
    {
        adaptee.jMenuHelpAbout_actionPerformed(actionEvent);
    }
}