package megamath;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * Description: MegaMath is a powerful GUI based application that allows the
 * user to calculate either the Greatest Common Divisor of two numbers of the
 * Factorial of one number.
 *
 * @author Alex Laird
 * @version 1.0
 * File: MegaMathFrame_AboutBox.java
 * Created: Sep 2008
 */
public class MegaMathFrame_AboutBox extends JDialog implements ActionListener
{
    JPanel panelAbout1 = new JPanel();
    JPanel panelAbout2 = new JPanel();
    JPanel insetsPanelAbout = new JPanel();
    JPanel insetsPanel2 = new JPanel();
    JPanel insetsPanel3 = new JPanel();
    JButton button1 = new JButton();
    JLabel imageLabel = new JLabel();
    JLabel label1 = new JLabel();
    JLabel label2 = new JLabel();
    JLabel label3 = new JLabel();
    JLabel label6 = new JLabel();
    ImageIcon image1 = new ImageIcon();
    BorderLayout borderLayoutMegaMathFrame_AboutBox = new BorderLayout();
    BorderLayout borderLayoutMegaMathFrame_AboutBox_panelAbout = new BorderLayout();
    FlowLayout flowLayoutMegaMathFrame_AboutBox = new FlowLayout();
    GridLayout gridLayout1 = new GridLayout();
    String product = "MegaMath";
    String version = "";
    String copyright = "Alex Laird";
    String comments = "MegaMath is a powerful GUI based application that allows the user to calculate either the Greatest Common Divisor of two numbers of the Factorial of one number.";
    JLabel label7 = new JLabel();
    JLabel label8 = new JLabel();
    JLabel label9 = new JLabel();
    JLabel label4 = new JLabel();
    JLabel label5 = new JLabel();

    public MegaMathFrame_AboutBox(Frame parent)
    {
        super(parent);

        try
        {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public MegaMathFrame_AboutBox()
    {
        this(null);
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception
     */
    private void jbInit() throws Exception
    {
        image1 = new ImageIcon(megamath.MegaMathFrame.class.getResource("about.png"));
        imageLabel.setIcon(image1);
        setTitle("About");
        panelAbout1.setLayout(borderLayoutMegaMathFrame_AboutBox);
        panelAbout2.setLayout(borderLayoutMegaMathFrame_AboutBox_panelAbout);
        insetsPanelAbout.setLayout(flowLayoutMegaMathFrame_AboutBox);
        insetsPanel2.setLayout(flowLayoutMegaMathFrame_AboutBox);
        insetsPanel2.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        gridLayout1.setRows(9);
        gridLayout1.setColumns(1);
        label1.setText(product);
        label2.setText(version);
        label3.setText("Created by Alex Laird");
        label6.setText("MegaMath is a powerful GUI based application");
        insetsPanel3.setLayout(gridLayout1);
        insetsPanel3.setBorder(BorderFactory.createEmptyBorder(10, 60, 10, 10));
        button1.setText("OK");
        button1.addActionListener(this);
        label7.setText("that allows the user to calculate either the Greatest");
        label8.setText("Common Divisor of two numbers of the Factorial of");
        label9.setText("one number.");
        label4.setText("September, 2008");
        insetsPanel2.add(imageLabel, null);
        panelAbout2.add(insetsPanel2, BorderLayout.WEST);
        getContentPane().add(panelAbout1, null);
        insetsPanel3.add(label1, null);
        insetsPanel3.add(label2, null);
        insetsPanel3.add(label3, null);
        insetsPanel3.add(label4);
        insetsPanel3.add(label5);
        insetsPanel3.add(label6, null);
        insetsPanel3.add(label7);
        insetsPanel3.add(label8);
        insetsPanel3.add(label9);
        panelAbout2.add(insetsPanel3, BorderLayout.CENTER);
        insetsPanelAbout.add(button1, null);
        panelAbout1.add(insetsPanelAbout, BorderLayout.SOUTH);
        panelAbout1.add(panelAbout2, BorderLayout.NORTH);
        setResizable(true);
    }

    /**
     * Close the dialog on a button event.
     *
     * @param actionEvent ActionEvent
     */
    public void actionPerformed(ActionEvent actionEvent)
    {
        if (actionEvent.getSource() == button1)
        {
            dispose();
        }
    }
}
