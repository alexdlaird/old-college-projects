package megamath;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class contains a generic dialog for displaying the answer to a problem;
 * the description and answer can be passed in to the constructor and the
 * dialog will then be called.
 *
 * @author Alex Laird
 * @version 1.0
 * File: AnswerDialog.java
 * Created: Sep 2008
 */
public class AnswerDialog extends JDialog implements ActionListener
{
    JPanel panel1 = new JPanel();
    JPanel jPanel1 = new JPanel();
    FlowLayout flowLayout1 = new FlowLayout();
    JButton jButtonOK = new JButton();
    GridLayout gridLayout1 = new GridLayout();
    JPanel jPanel3 = new JPanel();
    JLabel jLabelTopCenter = new JLabel();
    JLabel jLabel = new JLabel();
    JTextField jTextFieldAnswer = new JTextField();

    // initialization of default constructor
    public AnswerDialog(Frame owner, String title, boolean modal)
    {
        super(owner, title, modal);

        try
        {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    // constructor for each math case (GCD or Factorial) so only one dialog needs to be used
    public AnswerDialog(Frame parent, String title, boolean modal, String number, double answer)
    {
        super(parent, title, modal);

        try
        {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();

            jLabelTopCenter.setText(title + " Answer:");
            jLabel.setText("The " + title + " of " + number + " is:");
            jTextFieldAnswer.setText("" + answer);
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    // default constructor
    public AnswerDialog()
    {
        this(new Frame(), "", false);
    }

    private void jbInit() throws Exception
    {
        panel1.setLayout(gridLayout1);
        panel1.setMinimumSize(new Dimension(470, 30));
        panel1.setPreferredSize(new Dimension(470, 30));
        jPanel1.setMinimumSize(new Dimension(57, 33));
        jPanel1.setPreferredSize(new Dimension(57, 33));
        jPanel1.setLayout(flowLayout1);
        jButtonOK.setText("OK");
        jButtonOK.addActionListener(this);
        gridLayout1.setColumns(2);
        gridLayout1.setRows(1);
        jPanel3.setMinimumSize(new Dimension(57, 33));
        jPanel3.setPreferredSize(new Dimension(57, 33));
        jLabelTopCenter.setText("Answer:");
        jLabel.setText("Computed Answer");
        jTextFieldAnswer.setEditable(false);
        jTextFieldAnswer.setText("Answer");
        this.getContentPane().add(jPanel1, java.awt.BorderLayout.SOUTH);
        jPanel1.add(jButtonOK);
        this.getContentPane().add(jPanel3, java.awt.BorderLayout.NORTH);
        jPanel3.add(jLabelTopCenter);
        this.getContentPane().add(panel1, java.awt.BorderLayout.CENTER);
        panel1.add(jLabel);
        panel1.add(jTextFieldAnswer);
    }

    /**
     * Close the dialog on a button event.
     *
     * @param actionEvent ActionEvent
     */
    public void actionPerformed(ActionEvent actionEvent)
    {
        if (actionEvent.getSource() == jButtonOK)
        {
            dispose();
        }
    }
}
