package stack;

import myutil.Sequence;
import myutil.ArraySequence;
import java.util.Stack;
import java.util.EmptyStackException;

public class SequenceStack implements Stack
{
	protected static Sequence sequenceStack;
	
	public SequenceStack()
	{
		sequenceStack = new ArraySequence();
	}
	
	public static int size()
	{
		return sequenceStack.size();
	}
	
	public static boolean isEmpty()
	{
		return sequenceStack.isEmpty();
	}
	
	public static Object top() throws EmptyStackException
	{
		if(size() > 0)
			return sequenceStack.elemAtRank(size() - 1);
		else
			throw new EmptyStackException();
	}
	
	public static void push(Object element)
	{
		sequenceStack.insertAtRank(size(), element);
	}
	
	public static Object pop() throws EmptyStackException
	{
		if(size() > 0)
			return sequenceStack.removeAtRank(size() - 1);
		else
			throw new EmptyStackException();
	}
}
