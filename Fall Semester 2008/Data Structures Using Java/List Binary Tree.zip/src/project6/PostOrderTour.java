package project6;

public class PostOrderTour extends EulerTour
{
	/**
	 * Instantiate a new post order tour
	 * 
	 * @param newTree
	 */
	public PostOrderTour(BinaryTree newTree)
	{
		super(newTree);
	}
	
	/**
	 * Perform the post order tour
	 * 
	 * @return the tour object
	 */
	public Object tour()
	{
		return performTour(tree.root());
	}
	
    /**
     * Performed if the current node is external (has no children)
     * 
     * @param pos is the external node being visited
     * @param result is a storage mechanism for results computed as this node
     */
    protected void visitExternal (Position pos, TraversalResult result)
    {
    	visitPostorder(pos, result);
    }
    
    /**
     * Performed for every node in the post order tour
     * 
     * @param pos is the node being visited
     * @param result is a storage mechanism for results computed as this node
     */
    protected void visitPostorder (Position pos, TraversalResult result)
    {
    	System.out.print(pos.element() + " ");
    }	
}
