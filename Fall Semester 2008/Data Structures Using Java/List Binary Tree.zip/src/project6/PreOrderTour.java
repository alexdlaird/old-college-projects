package project6;


public class PreOrderTour extends EulerTour
{
	/**
	 * Instantiate a new pre order tour
	 * 
	 * @param newTree
	 */
	public PreOrderTour(BinaryTree newTree)
	{
		super(newTree);
	}
	
	/**
	 * Perform the pre order tour
	 * 
	 * @return the tour object
	 */
	public Object tour()
	{
		return performTour(tree.root());
	}
	
    /**
     * Performed if the current node is external (has no children)
     * 
     * @param pos is the external node being visited
     * @param result is a storage mechanism for results computed as this node
     */
    protected void visitExternal (Position pos, TraversalResult result)
    {
    	visitPreorder(pos, result);
    }
    
    /**
     * Performed for every node in the pre order tour
     * 
     * @param pos is the node being visited
     * @param result is a storage mechanism for results computed as this node
     */
    protected void visitPreorder (Position pos, TraversalResult result)
    {
    	System.out.print(pos.element() + " ");
    }	
}
