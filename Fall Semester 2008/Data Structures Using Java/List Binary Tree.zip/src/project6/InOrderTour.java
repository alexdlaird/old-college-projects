package project6;

public class InOrderTour extends EulerTour
{
	/**
	 * Instantiate a new in order tour
	 * 
	 * @param newTree
	 */
	public InOrderTour(BinaryTree newTree)
	{
		super(newTree);
	}
	
	/**
	 * Perform the in order tour
	 * 
	 * @return the tour object
	 */	
	public Object tour()
	{
		return performTour(tree.root());
	}
	
    /**
     * Performed if the current node is external (has no children)
     * 
     * @param pos is the external node being visited
     * @param result is a storage mechanism for results computed as this node
     */
    protected void visitExternal (Position pos, TraversalResult result)
    {
    	visitInorder(pos, result);
    }
    
    /**
     * Performed for every node in the in order tour
     * 
     * @param pos is the node being visited
     * @param result is a storage mechanism for results computed as this node
     */
    protected void visitInorder (Position pos, TraversalResult result)
    {
    	System.out.print(pos.element() + " ");
    }	
}
