package project6;

/**
 * 
 * 
 * @author Alex Laird
 * @version 1.0
 */

public class BoundaryViolationException extends RuntimeException
{
    public BoundaryViolationException()
    {
        this ("Boundary Violation");
    }
    
    public BoundaryViolationException(String err)
    {
        super (err);
    }
}