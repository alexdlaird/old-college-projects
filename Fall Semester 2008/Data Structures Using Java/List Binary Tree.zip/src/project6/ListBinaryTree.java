package project6;

/**
 * 
 * @author Alex Laird
 * @version 1.0
 */
public class ListBinaryTree implements BinaryTree
{
	// declare and initialize variables
	static STNode	root = null;
	static int	size = 0;
	
	/**
	 * Fills an STNode tree for testing purposes.
	 */
    public void fillTree()
    {
        root = new STNode(new Integer(0), null, null, null);
        STNode node1 = new STNode(new Integer(1), root, null, null);
        STNode node2 = new STNode(new Integer(2), root, null, null);
        root.setLeftChild(node1);
        node1.setSibling(node2);

        STNode node3 = new STNode(new Integer(3), node1, null, null);
        STNode node4 = new STNode(new Integer(4), node1, null, null);
        node1.setLeftChild(node3);
        node3.setSibling(node4);

        STNode node5 = new STNode(new Integer(5), node2, null, null);
        STNode node6 = new STNode(new Integer(6), node2, null, null);
        node2.setLeftChild(node5);
        node5.setSibling(node6);

        STNode node7 = new STNode(new Integer(7), node3, null, null);
        STNode node8 = new STNode(new Integer(8), node3, null, null);
        node3.setLeftChild(node7);
        node7.setSibling(node8);

        STNode node9 = new STNode(new Integer(9), node4, null, null);
        STNode node10 = new STNode(new Integer(10), node4, null, null);
        node4.setLeftChild(node9);
        node9.setSibling(node10);

        size = 11;
    }
    
    /**
     * Returns the position of the root node.
     * 
     * @return a reference to the root node
     */
    public Position root() throws EmptyTreeException
    {
    	// ensure that the root exists
    	if(root == null)
    		throw new EmptyTreeException();
    	
    	return root;
    }
    
    /**
     * Returns the position of the left child of the current position.
     * 
     * @param pos is the node whose left child will be returned
     * @return a reference to left child of pos
     * @throws InvalidPositionException if the position given is not valid
     * @throws BoundaryViolationException if the position given is outside proper boundaries
     */
    public Position leftChild(Position pos) throws BoundaryViolationException
    {
    	STNode myNode = checkPosition(pos);
    	
    	// get the left child nodes position
    	Position leftPos = myNode.getLeftChild();
    	
    	// ensure that the left child exists
    	if(leftPos == null)
    		throw new BoundaryViolationException("No left child");
    	
    	return leftPos;
    }
    
    /**
     * Returns the position of the right child of the current position.
     * 
     * @param pos is the node whose right child will be returned
     * @return a reference to right child of pos
     * @throws InvalidPositionException if the position given is not valid
     * @throws BoundaryViolationException if the position given is outside proper boundaries
     */
    public Position rightChild(Position pos) throws InvalidPositionException, BoundaryViolationException
    {
    	STNode myNode = checkPosition(pos);
    	
    	return(myNode.getLeftChild().getSibling());
    }
    
    /**
     * Returns the sibling node of the current position.
     * 
     * @param pos is the node whose sibling will be returned
     * @return a reference to the sibling of pos
     * @throws InvalidPositionException if the position given is not valid
     * @throws BoundaryViolationException if the position given is outside proper boundaries
     */
    public Position sibling(Position pos) throws InvalidPositionException, BoundaryViolationException
    {
    	STNode myNode = checkPosition(pos);
    	
    	// get the sibling nodes position
    	Position siblingPos = myNode.getSibling();
    	
    	// ensure that the sibling node exists
    	if(siblingPos == null)
    		throw new BoundaryViolationException("No sibling");
    	
    	return(siblingPos);
    }
    
    /**
     * Returns the parent node of the current position.
     * 
     * @param pos is the node whose parent will be returned
     * @return a reference to the parent of pos
     * @throws InvalidPositionException if the position given is not valid
     * @throws BoundaryViolationException if the position given is outside proper boundaries
     */
    public Position parent(Position pos) throws InvalidPositionException, BoundaryViolationException
    {
    	STNode myNode = checkPosition(pos);
    	
    	// get the parent nodes position
    	Position parentPos = myNode.getParent();
    	
    	// ensure that the parent node exists
    	if(parentPos == null)
    		throw new BoundaryViolationException("No parent");
    	
    	return(parentPos);
    }

    /**
     * Checks to see if the node at the current position is internal (has children).
     * 
     * @param pos is the node which will be examined
     * @return true if node has 1 or 2 children
     * @throws InvalidPositionException if the position given is not valid
     */
    public boolean isInternal(Position pos) throws InvalidPositionException
    {
    	STNode myNode = checkPosition(pos);
    	
    	// check to ensure that the node has a left child
    	// if it has a left child, there is no need to check for a right child
    	if(myNode.getLeftChild() != null)
    		return true;
    	else
    		return false;
    }
    
    /**
     * Check to see whether the node at the current position is external (has no children).
     * 
     * @param pos is the node which will be examined
     * @return true if node has no children
     * @throws InvalidPositionException if the position given is not valid
     */
    public boolean isExternal(Position pos) throws InvalidPositionException
    {
    	checkPosition(pos);
    	
    	return(!isInternal(pos));
    }
    
    /**
     * Check to see if the current position is the root of the tree.
     * 
     * @param pos is the node which will be examined
     * @return true if the node is the root node
     * @throws InvalidPositionException if the position given is not valid
     */
    public boolean isRoot(Position pos) throws InvalidPositionException
    {
    	checkPosition(pos);
    	
    	return(pos == root());
    }

    /**
     * Returns the size.
     * 
     * @return the number of Positions (nodes) in the tree
     */
    public int size()
    {
    	return size;
    }
    
    /**
     * Returns whether the tree is empty or not.
     * 
     * @return true if the tree currently contains no Positions
     */
    public boolean isEmpty()
    {
    	return(size == 0);
    }
    
    /**
     * Tests to see whether the node at the current position has a left child.
     * 
     * @param pos the current position
     * @return true if the given position has a left child
     * @throws InvalidPositionException if the position given is not valid
     */
    protected boolean hasLeft(Position pos) throws InvalidPositionException
    {
    	STNode myNode = checkPosition(pos);
    	
    	return(myNode.getLeftChild() != null);
    }
    
    /**
     * Essentially testing to see if node at the current position has a right child,
     * indirectly finding out by checking for the sibling's left child.
     * 
     * @param pos the current position
     * @return true if the sibling of the given position has a left node
     * @throws InvalidPositionException if the position given is not valid
     */
    protected boolean hasSibling(Position pos) throws InvalidPositionException
    {
    	STNode myNode = checkPosition(pos);
    	
    	return(myNode.getSibling() != null);
    }
    
    /**
     * Ensures that the position given is a valid position within the tree.
     * 
     * @param pos
     * @return the node at the given position if the position is valid
     * @throws InvalidPositionException if the position given is not valid
     */
    protected STNode checkPosition(Position pos) throws InvalidPositionException
    {
    	// ensure that the position exists and that it is an instance of an STNode
    	if(pos == null || !(pos instanceof STNode))
    		throw new InvalidPositionException();
    	
    	// since the exception was not caught, return the STNode at that position
    	return (STNode) pos;
    }
    
    /**
     * The main method from which the program is executed and all testing is called.
     * 
     * @param args unused
     */
    public static void main(String[] args)
    {
    	// fill up the tree
        ListBinaryTree myTree = new ListBinaryTree();
        myTree.fillTree();
        
        // perform the pre order euler's tour
        System.out.print("Pre Order Tour: ");
        PreOrderTour preOrderTour = new PreOrderTour(myTree);
        preOrderTour.tour();
        
        // perform the in order euler's tour
        System.out.print("\nIn Order Tour: ");
        InOrderTour inOrderTour = new InOrderTour(myTree);
        inOrderTour.tour();
        
        // perform the post order euler's tour
        System.out.print("\nPost Order Tour: ");
        PostOrderTour postOrderTour = new PostOrderTour(myTree);
        postOrderTour.tour();
    }
}