package termproject;

public class ElementNotFoundException  extends RuntimeException
{
    public ElementNotFoundException()
    {

    }
}
