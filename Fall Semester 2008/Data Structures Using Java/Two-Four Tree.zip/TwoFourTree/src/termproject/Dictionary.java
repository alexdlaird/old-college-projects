package termproject;

/**
 * Term Project 2-4 Trees
 *
 * @author Dr. Gallagher
 * @version 1.0
 * Created 2 Mar 2001
 * Summary of Modifications:
 *
 * Description: findElement and removeElement will return null if item not
 * found.
 */

public interface Dictionary {

    public int size();
    public boolean isEmpty();

    public Object findElement (Object key) throws ElementNotFoundException;

    public void insertElement (Object key, Object element);

    public Object removeElement (Object key) throws ElementNotFoundException;
}
