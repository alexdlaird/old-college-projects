package termproject;

/**
 * Title:        Project #7
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidIntegerException extends RuntimeException {

    public InvalidIntegerException(String errorMsg) {
        super (errorMsg);
    }
}