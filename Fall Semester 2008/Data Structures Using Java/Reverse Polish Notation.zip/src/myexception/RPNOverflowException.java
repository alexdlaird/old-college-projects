package myexception;

/**
 * An exception class which is thrown when the RPN equation has too many numerical values and not enough mathematical
 * operators with which to evaluate them.
 *
 * @author Alex Laird
 * @version 1.0
 * File: RPNOverflowException.java
 * Created: Oct 2008
 */

public class RPNOverflowException extends RuntimeException
{
	public RPNOverflowException()
	{
		// unused constructor
	}
	
	public RPNOverflowException(String msg)
	{
		// pass error message to RuntimeException
		super(msg);
	}
}
