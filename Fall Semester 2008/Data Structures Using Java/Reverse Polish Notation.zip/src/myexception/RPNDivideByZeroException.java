package myexception;

/**
 * An exception class which is thrown when the RPN equation attempts
 * to divide by zero.
 *
 * @author Alex Laird
 * @version 1.0
 * File: RPNDivideByZeroException.java
 * Created: Oct 2008
 */

public class RPNDivideByZeroException extends RuntimeException
{
	public RPNDivideByZeroException()
	{
		// unused constructor
	}
	
	public RPNDivideByZeroException(String msg)
	{
		// pass error message to RuntimeException
		super(msg);
	}
}
