package myexception;

/**
 * An exception class which is thrown when there is no RPN equation to be evaluated.
 *
 * @author Alex Laird
 * @version 1.0
 * File: EmptyRPNException.java
 * Created: Oct 2008
 */

public class EmptyRPNException extends RuntimeException
{
	public EmptyRPNException()
	{
		// unused constructor
	}
	
	public EmptyRPNException(String msg)
	{
		// pass error message to RuntimeException
		super(msg);
	}
}
