package myexception;

/**
 * An exception class which is thrown when the RPN equation has a mathematical operator before there are enough
 * numerical values for it to evaluate.
 *
 * @author Alex Laird
 * @version 1.0
 * File: RPNUnderflowException.java
 * Created: Oct 2008
 */

public class RPNUnderflowException extends RuntimeException
{
	public RPNUnderflowException()
	{
		// unused constructor
	}
	
	public RPNUnderflowException(String msg)
	{
		// pass error message to RuntimeException
		super(msg);
	}
}
