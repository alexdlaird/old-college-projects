package myexception;

/**
 * An exception class which is thrown when the RPN equation is a String which is unable to be manipulated.
 *
 * @author Alex Laird
 * @version 1.0
 * File: InvalidRPNException.java
 * Created: Oct 2008
 */

public class InvalidRPNException extends RuntimeException
{
	public InvalidRPNException()
	{
		// unused constructor
	}
	
	public InvalidRPNException(String msg)
	{
		// pass error message to RuntimeException
		super(msg);
	}
}
