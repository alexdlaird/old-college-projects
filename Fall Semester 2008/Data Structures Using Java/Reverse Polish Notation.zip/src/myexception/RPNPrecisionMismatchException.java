package myexception;

/**
 * An exception class which is thrown when the calculated answer of the RPN equation does not match the correct answer.
 *
 * @author Alex Laird
 * @version 1.0
 * File: RPNPrecisionMismatchException.java
 * Created: Oct 2008
 */

public class RPNPrecisionMismatchException extends RuntimeException
{
	public RPNPrecisionMismatchException()
	{
		// unused constructor
	}
	
	public RPNPrecisionMismatchException(String msg)
	{
		// pass error message to RuntimeException
		super(msg);
	}
}
