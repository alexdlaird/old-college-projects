package project7;

/**
 * This class implements and tests an expandable ArrayHeap using
 * the provided code from Dr. Gallagher.  The only other method edited
 * was InvalidIntegerException, which was required for the
 * IntegerComparator class.
 * 
 * @author Alex Laird
 * @version 1.0
 */
public class ArrayHeap extends ArrayBinaryTree implements Heap
{
    Comparator	heapComp;

    /**
     * 
     * @param newComp a comparator for the ArrayHeap
     */
    public ArrayHeap(Comparator newComp)
    {
        this (newComp, DEFAULT_SIZE);
    }
    
    /**
     * 
     * @param newComp a comparator for the ArrayHeap
     * @param newSize an initial size for the ArrayHeap
     */
    public ArrayHeap(Comparator newComp, int newSize)
    {
        super (newSize);
        heapComp = newComp;
    }
    
    /**
     * Adds a given Object to the ArrayHeap.
     * 
     * @param newElement the element to be added to the ArrayHeap
     * @throws InvalidObjectException if the element to be added is not a valid object
     */
	public void add(Object newElement) throws InvalidObjectException
	{
		// ensure that an element was given
		if(newElement == null)
			throw new InvalidObjectException("Null object.");
		
		// expand the ArrayHeap, if necessary
		if(size == capacity)
			expand();
		
		// ensure that the object passed is valid for our ArrayHeap
		try
		{
			// instantiate a new ArrayPosition for the new element
			ArrayPosition insertPos = new ArrayPosition(size, newElement);
			
			// insert the new element and increment size
			btArray[size] = insertPos;
			size++;
			
			// bubble the element up to its proper location to ensure a proper ArrayHeap
			bubbleUp(insertPos);
		}
		catch(ClassCastException c)
		{
			throw new InvalidObjectException("Invalid object.");
		}
	}

	/**
	 * Removes the root node (smallest Object) from the ArrayHeap.
	 * 
	 * @return the root node (smallest Object)
	 * @throws EmptyHeadException if the ArrayHeap is empty
	 */
	public Object removeRoot() throws EmptyHeapException
	{
		// ensure that the ArrayHeap isn't already empty
		if(isEmpty())
			throw new EmptyHeapException("The heap is empty.");
		
		Object min = root().element();
    	
		// set the node farthest down and to the right (most recently added) as the new root
    	btArray[ROOT] = btArray[size - 1];
    	btArray[ROOT].setIndex(ROOT);
    	// set the root to null
    	btArray[size - 1] = null;
		
    	// bubble the new root down to its proper location to ensure a proper ArrayHeap
    	bubbleDown((ArrayPosition) root());
    	size--;
    	
    	return min;
	}
	
	/**
	 * Doubles the size ArrayHeap when capacity is reached
	 */
	private void expand()
	{
		int newSize = capacity * 2;
		
		// create a new array twice the size
		ArrayPosition[] newArray = new ArrayPosition[newSize];
		
		// copy all the data from the old array into our new array
		for(int i = 0; i < capacity; i++)
			newArray[i] = btArray[i];
		
		// point our array to the new array and assign the new capacity
		btArray = newArray;
		capacity = newSize;
	}
	
	/**
	 * Swaps two ArrayPosition Objects.
	 * 
	 * @param first first ArrayPosition to be swapped
	 * @param second second ArrayPosition to be swapped
	 */
	private void swap(ArrayPosition first, ArrayPosition second)
	{
		Object temp = first.element();
		first.setElement(second.element());
		second.setElement(temp);
	}
	
	/**
	 * Bubbles up an element at a given position until it is greater than its parent or has reached the root.
	 * 
	 * @param pos the position pointer to the element to be bubbled up
	 */
    private void bubbleUp(ArrayPosition pos)
    {
    	// continue swapping with the above element until the ArrayHeap is proper
    	while(pos != root() && heapComp.isLessThan(pos.element(), parent(pos).element()))
    	{
    		swap(pos, (ArrayPosition) parent(pos));
    		pos = (ArrayPosition) parent(pos);
    	}
    }
    
    /**
     * Bubbles down an element at a given position until is it less than its parent or has reached the bottom of the ArrayHeap.
     * 
     * @param pos the position pointer to the element to be bubbled down
     */
    private void bubbleDown(ArrayPosition pos)
    {
		Position smallest = null;
		
		// continue swapping with the below element (left or right) until the ArrayHeap is proper
		while(pos != null)
		{
			// get out if there is not left child or no right child
			if(leftChild(pos) == null || rightChild(pos) == null)
				break;
			
			// check if there is only a left child
			if(leftChild(pos) != null && rightChild(pos) == null)
				// if the left child is less than the right child, swap and get out
				if(heapComp.isLessThan(leftChild(pos).element(), pos.element()))
				{
					swap((ArrayPosition) leftChild(pos), pos);
					
					break;
				}
			
			// check which child is smaller
			if(heapComp.isLessThan(leftChild(pos).element(), rightChild(pos).element()))
				smallest = leftChild(pos);
			else
				smallest = rightChild(pos);
			
			// check if the child is smaller than the current position
			if(heapComp.isLessThan(smallest.element(), pos.element()))
			{
				// swap two ArrayPosition elements
				swap((ArrayPosition) pos, (ArrayPosition) smallest);
				pos = (ArrayPosition) smallest;
			}
			else
				pos = null;
		}
    }
    
	/**
	 * Will set all values of an array to null
	 * 
	 * @param array is the array who's values are to be set to null
	 * @return the array with each value set to null
	 */
	public static Object[] nullArray(Object[] array)
	{
		for(int i = 0; i < array.length; i++)
			array[i] = null;

		return array;
	}

	/**
	 * The main method from which the program is executed and all tests are run.
	 * 
	 * @param args Unused
	 */
    public static void main (String[] args)
    {
        Comparator myComp = new IntegerComparator();
        
        /*
         * Test #1: Add and remove nodes
         */
        System.out.println("Test #1: Add and remove nodes and cause the ArrayHeap to resize.");
        
        Heap heap1 = new ArrayHeap(myComp, 8);

        heap1.add(new Integer(14));
        heap1.add(new Integer(17));
        heap1.add(new Integer(3));
        heap1.add(new Integer(21));
        heap1.add(new Integer(8));
        heap1.add(new Integer(18));
        heap1.add(new Integer(1));
        heap1.add(new Integer(11));
        heap1.add(new Integer(17));
        heap1.add(new Integer(6));

        System.out.println("Current Size: " + heap1.size());
        
        while (!heap1.isEmpty())
        {
            Integer removedInt = (Integer) heap1.removeRoot();
            System.out.println("Removed " + removedInt);
        }

        System.out.println("All nodes added and removed properly.");
        
        /*
         * Test #2: Add invalid Objects
         */
        System.out.println("\nTest #2: Try to add something that isn't an object.");
        
        Heap heap2 = new ArrayHeap(myComp, 5);
        
        try
        {
        	heap2.add("Hi");
        	heap2.add("This will");
        	heap2.add("Cause errors ...");
        }
        catch(InvalidIntegerException c)
        {
        	System.out.println("The object was not an Integer.");
        }
        
        /*
         * Test #3: Remove when the ArrayHeap is empty
         */
        System.out.println("\nTest #3: Remove from the heap when it is empty.");
        Heap heap3 = new ArrayHeap(myComp, 5);
        
        try
        {
	        heap3.add(new Integer(3));
	        heap3.add(new Integer(7));
	        heap3.removeRoot();
	        heap3.removeRoot();
	        heap3.removeRoot();
        }
        catch(EmptyHeapException c)
        {
        	System.out.println("Tried removing from the ArrayHeap when it was empty.");
        }
    }
}