package project7;

/**
 * Title:        Project #7
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author Alex Laird
 * @version 1.0
 */

public class InvalidIntegerException extends RuntimeException {

    public InvalidIntegerException(String errorMsg) {
        super (errorMsg);
    }
}
