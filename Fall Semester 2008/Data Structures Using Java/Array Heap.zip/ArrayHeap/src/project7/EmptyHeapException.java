package project7;

/**
 * Title:        Project #7
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author Dr. Gallagher
 * @version 1.0
 */

public class EmptyHeapException extends RuntimeException {

    public EmptyHeapException(String errorMsg) {
        super (errorMsg);
    }
}