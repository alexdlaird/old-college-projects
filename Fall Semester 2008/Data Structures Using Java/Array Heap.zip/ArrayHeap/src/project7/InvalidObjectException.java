package project7;

/**
 * Title:        Project #7
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author Dr. Gallagher
 * @version 1.0
 */

public class InvalidObjectException extends RuntimeException {

    public InvalidObjectException(String errorMsg) {
        super (errorMsg);
    }
}
