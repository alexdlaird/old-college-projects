package queue;

import myexception.QueueEmptyException;

/**
 * The interface for a generic queue.
 * 
 * @author Alex Laird
 * @version 1.0
 * File: Queue.java
 * Created: Oct 2008
 *
 * @param <E> defines the generics for the queue
 */
public interface Queue<E>
{
	public void enqueue(E element);
	public E dequeue() throws QueueEmptyException;
	public E front() throws QueueEmptyException;
	public int size();
	public boolean isEmpty();
}
