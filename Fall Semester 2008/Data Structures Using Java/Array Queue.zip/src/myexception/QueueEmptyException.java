package myexception;

/**
 * An exception class which is thrown when the queue is empty when the front element is called.
 * 
 * @author Alex Laird
 * @version 1.0
 * File: QueueEmptyException.java
 * Created: Oct 2008
 */
public class QueueEmptyException extends RuntimeException
{
	public QueueEmptyException()
	{
		
	}
	
	public QueueEmptyException(String msg)
	{
		super(msg);
	}
}
